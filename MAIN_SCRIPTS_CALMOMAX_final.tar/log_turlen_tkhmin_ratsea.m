function xnolog=log_turlen_tkhmin_ratsea(xlog,paramname) 

% NAME 
%   log_turlen_entrsc
% PURPOSE 
%   convert the optimal parameters (tur_len and entr_sc) values from log-space back to the regular space
% INPUTS 
%   xlog - input vector of paramaeters values in log space
%   paramname - parameter names
% OUTPUT
%   xnolog - output vector of paramaeters values (tur_len and entr_sc) in regular space
% AUTHOR  
%   Itsik Carmona (carmonai@ims.gov.il)

if strcmp(paramname,'tur_len')
    xmaxmin=[100,1000];    
	xdefault=150;
    xlogminmax=[-1.386294361119891,4.280132326992542];
    xlogdef=1.446918982936325;
elseif strcmp(paramname,'tkhmin')
    xmaxmin=[0.1,2];
	xdefault=0.4;
    xlogminmax=[2.890371757896165,6.238324625039508];
    xlogdef=4.564348191467836;
elseif strcmp(paramname,'rat_sea')
    xmaxmin=[1,50];
    xdefault=10;
    xlogminmax=[3.9702919, 6.9536842];
    xlogdef=5.4620142;
end

b=exp(xlogminmax(1));
a=(exp(xlogdef)-b)*(xmaxmin(2)-xmaxmin(1))/(xdefault-xmaxmin(1));
xnolog=((exp(xlog)-b)*(xmaxmin(2)-xmaxmin(1))/a)+xmaxmin(1);
testlog=log(a*(xnolog-xmaxmin(1))/(xmaxmin(2)-xmaxmin(1))+b);   %check 
        
