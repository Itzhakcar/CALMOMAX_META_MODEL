function [Spec_Date2,Specjulian]=Dates_count2()
%%%%%%%%%%%%%%%% Please write the dates 4 digits for year , 2 digits for
%%%%%%%%%%%%%%%% month and 2 digits for day
Spec_Date2{1}='20190102';
Spec_Date2{2}='20190109';
Spec_Date2{3}='20190114';
Spec_Date2{4}='20190119';
Spec_Date2{5}='20190123';
Spec_Date2{6}='20190205';
Spec_Date2{7}='20190207';
Spec_Date2{8}='20190212';
Spec_Date2{9}='20190214';
Spec_Date2{10}='20190222';
Spec_Date2{11}='20190302';
Spec_Date2{12}='20190312';
Spec_Date2{13}='20190314';
Spec_Date2{14}='20190316';
Spec_Date2{15}='20190327';
Spec_Date2{16}='20190405';
Spec_Date2{17}='20190411';
Spec_Date2{18}='20190414';
Spec_Date2{19}='20190417';
Spec_Date2{20}='20190420';
Spec_Date2{21}='20190504';
Spec_Date2{22}='20190507';
Spec_Date2{23}='20190513';
Spec_Date2{24}='20190523';
Spec_Date2{25}='20190527';
Spec_Date2{26}='20190601';
Spec_Date2{27}='20190605';
Spec_Date2{28}='20190610';
Spec_Date2{29}='20190614';
Spec_Date2{30}='20190617';
Spec_Date2{31}='20190705';
Spec_Date2{32}='20190710';
Spec_Date2{33}='20190716';
Spec_Date2{34}='20190718';
Spec_Date2{35}='20190722';
Spec_Date2{36}='20190804';
Spec_Date2{37}='20190815';
Spec_Date2{38}='20190816';
Spec_Date2{39}='20190817';
Spec_Date2{40}='20190824';
Spec_Date2{41}='20190901';
Spec_Date2{42}='20190912';
Spec_Date2{43}='20190914';
Spec_Date2{44}='20190920';
Spec_Date2{45}='20190923';
Spec_Date2{46}='20191002';
Spec_Date2{47}='20191007';
Spec_Date2{48}='20191017';
Spec_Date2{49}='20191024';
Spec_Date2{50}='20191030';
Spec_Date2{51}='20191103';
Spec_Date2{52}='20191109';
Spec_Date2{53}='20191112';
Spec_Date2{54}='20191115';
Spec_Date2{55}='20191124';
Spec_Date2{56}='20191201';
Spec_Date2{57}='20191203';
Spec_Date2{58}='20191210';
Spec_Date2{59}='20191213';
Spec_Date2{60}='20191224';



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%% The stage of calulation: calculating the Specjulian vector
%%%%%%%%%%%%%%%%% The Julian Date calcuation, the number of the day in the
%%%%%%%%%%%%%%%%% year for example Jan the 13th is Specjulian = 13 and
%%%%%%%%%%%%%%%%% Feb the 2sd is juliannumber=30 (not in leap year) or
%%%%%%%%%%%%%%%%% juliannumber=31 in leap year. and etc....
%%%%%%%%%%%%%% 
monthday=[31;28;31;30;31;30;31;31;30;31;30;31];
monthdayleap=monthday;
monthdayleap(2)=29; % in leap years Feb has 29 days.
Specjulian=NaN(1,length(Spec_Date2));
for i=1:length(Spec_Date2)
    year=str2double(Spec_Date2{i}(1:4));
    month=str2double(Spec_Date2{i}(5:6));
    day=str2double(Spec_Date2{i}(7:8));
    if(abs(year-floor(year/4)*4)<0.0001)
Specjulian(i)=sum(monthdayleap(1:(month-1)))+day;
    else
       Specjulian(i)=sum(monthday(1:(month-1)))+day; 
    end
end
