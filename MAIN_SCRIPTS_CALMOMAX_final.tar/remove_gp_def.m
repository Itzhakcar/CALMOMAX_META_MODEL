function [small_datamatrix,grid_datamatrix,calmo_matrix_2D_size]=remove_gp_def(datamatrix_new,fields_all)

% if 'fields_all' =1 then in all fileds the observations and forecast most
% be avaliable
% (Forecast data must be for all simulations including default and all moddata simulation and all constrain simuationS (if constrain exist)  and val simultion if val exist)

% if 'filelds_all'=0 then at least one field must have avaliable data or in other
% words there is no need that all fields must be avaliable with data
XYmap=[];
NumberOneD=size(datamatrix_new.obsdata,4)*size(datamatrix_new.obsdata,5);
datatemp.obsdata=datamatrix_new.obsdata(1:size(datamatrix_new.obsdata,1),1:size(datamatrix_new.obsdata,2),1:size(datamatrix_new.obsdata,3),:);
nanmean(datatemp.obsdata(3,:))
datatemp.refdata=datamatrix_new.refdata(1:size(datamatrix_new.refdata,1),1:size(datamatrix_new.refdata,2),1:size(datamatrix_new.refdata,3),:);
datatemp.moddata=datamatrix_new.moddata(1:size(datamatrix_new.moddata,1),1:size(datamatrix_new.moddata,2),1:size(datamatrix_new.moddata,3),:);
if isfield(datamatrix_new, 'valdata')
    datatemp.valdata=datamatrix_new.valdata(1:size(datamatrix_new.valdata,1),1:size(datamatrix_new.valdata,2),1:size(datamatrix_new.valdata,3),:);
end
if isfield(datamatrix_new, 'constrain')
    datatemp.constrain=datamatrix_new.constrain(1:size(datamatrix_new.constrain,1),1:size(datamatrix_new.constrain,2),1:size(datamatrix_new.constrain,3),:);
end
if(fields_all==1)
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % 'XYmap' is the matrix 2D map of existed grid pointes (for observation, defatult simulation (REF) , all mod-simulations and interaction simulations (moddata), %
    %constrain simulations and val simulation), represented by index j and i (j is the line number (raw number for upper line to bottom line) and i is the coulmn number from left to right)
    %%%%%%%%%%%%%%%%%%%%%%%%%%
    clear number_of_val_data number_of_constrain_data
    number_of_obs_data=size(datamatrix_new.obsdata,1); % the maximum nuber of observation for each grid point. number of of fields
    number_of_ref_data=number_of_obs_data; % because REF has only one simulation, therefore, the number of fields should be same as 'number_of_obs_data'
    number_of_mod_data=number_of_obs_data*size(datamatrix_new.moddata,3); % the number of Modatat is like the number of obs data multiple by the number of simulation of Moddata.
    if isfield(datamatrix_new, 'valdata')
        number_of_val_data=number_of_obs_data % the number of Val data is like the number of obs data because there is one simulation of val.
    end
    if isfield(datamatrix_new, 'constrain')
        number_of_constrain_data=number_of_obs_data*size(datamatrix_new.constrain,3); % the number of constrain is like the number of obs data multiple by the number of simulationS of constatin % the number of Val data is like the number of obs data because there is one simulation of val.
    end
    % running on all grid points
    
    % for i=1:size(datatemp.obsdata,4) % runing on all raws in for checking the exsitence of each grid point, the 1D gridd matrix datatemp
    %    i
    for day=1:size(datamatrix_new.obsdata,2) % runing on all fileds in order to check existence of each grid point
        number_of_exist_obs=zeros(NumberOneD,1); % number of exist observation for the grid points which is the number of avaliable fields for the spcific day
        number_of_exist_ref=zeros(NumberOneD,1); % number of exist Reference simulation for the grid points which is the number of avaliable fields for the spcific day
        number_of_exist_moddata=zeros(NumberOneD,1); % number of exist Reference simulation for the grid points which is the number of avaliable fields for the spcific day
        number_of_exist_val=zeros(NumberOneD,1); % number of exist val simulation for the grid points which is the number of avaliable avaliable fields for the spcific day
        number_of_exist_constrain=zeros(NumberOneD,1); % number of exist constrain simulationS for the grid points which is the number of avaliable fields for the spcific day
        number_of_exist_obs=squeeze(sum(~isnan(datatemp.obsdata(1:size(datamatrix_new.obsdata,1),day,1,:))));  % checking if there is an avaliable observation in the specific field and day
        number_of_exist_ref=squeeze(sum(~isnan(datatemp.refdata(1:size(datamatrix_new.refdata,1),day,1,:))));  % checking if there is an avaliable Ref simulation forecast in the specific field and day.
        if isfield(datamatrix_new, 'valdata')
            number_of_exist_val=squeeze(sum(~isnan(datatemp.valdata(1:size(datamatrix_new.valdata,1),day,1,:)))); % checking if there is an avaliable Ref simulation forecast in the specific field and day.
        end
        for imoddata=1:size(datatemp.moddata,3)
            length(sum(~isnan(datatemp.moddata(1:size(datamatrix_new.moddata,1),day,imoddata,:))));
            number_of_exist_moddata=number_of_exist_moddata+squeeze(sum(~isnan(datatemp.moddata(1:size(datamatrix_new.moddata,1),day,imoddata,:)))); % checking if there is an avaliable observation in the specific field and day.
        end
        if isfield(datamatrix_new, 'constrain')
            for iconstrain=1:size(datatemp.constrain,3)
                number_of_exist_constrain=number_of_exist_constrain+squeeze(sum(~isnan(datatemp.constrain(1:size(datamatrix_new.constrain,1),day,iconstrain,:)))); % checking if there is an avaliable constrain simuation forecast in the specific field and day.;
            end
        end
        % end % end of fields loop
        % FOUR BLOCKS of "IF COMMAND" FOR 4 combinations with val and constatin if
        % they exist or not , 2 ^2 gives 4 combination.
        %I tried in 'ELSEIF' command and it did not succed therefore i disccueded to try four blocks of "IF COMMAND"
        %%% THE FOUR if condiations is for the 4
        %%% condistions are for the following situations:
        % 1.) val
        %%%simulation and constrain simulations
        %%% do not exist
        if(~isfield(datamatrix_new, 'valdata') && ~isfield(datamatrix_new, 'constrain'))
            XYmap=[XYmap;find(number_of_exist_moddata==number_of_mod_data & number_of_exist_ref==number_of_ref_data & number_of_exist_obs==number_of_obs_data)];
            
            
        end % end of if conditation to check (to fill) matrix variable 'XYmap'
        % 2.) val simulation exist whereas constrain simulations
        % do not exist
        if(~isfield(datamatrix_new, 'constrain') && isfield(datamatrix_new, 'valdata'))
            
            XYmap=[XYmap;find(number_of_exist_moddata==number_of_mod_data & number_of_exist_ref==number_of_ref_data & number_of_exist_obs==number_of_obs_data & number_of_exist_val==number_of_val_data)];
            
            
        end % end of if conditation to check (to fill) matrix variable 'XYmap'
        % 3.) val simulation does not exist whereas constrain
        % simulations
        % do exist
        if(~isfield(datamatrix_new, 'valdata') && isfield(datamatrix_new, 'constrain'))
            XYmap=[XYmap;find(number_of_exist_moddata==number_of_mod_data & number_of_exist_ref==number_of_ref_data & ...
                number_of_exist_obs==number_of_obs_data & number_of_exist_constrain==number_of_constrain_data)];
            
        end % end of if conditation to check (to fill) matrix variable 'XYmap'
        % 4.) val simulation and constrain simulations
        % do exist
        if(isfield(datamatrix_new, 'constrain') && isfield(datamatrix_new, 'valdata'))
            
            XYmap=[XYmap;find(number_of_exist_moddata==number_of_mod_data & number_of_exist_ref==number_of_ref_data & number_of_exist_obs==number_of_obs_data & ...
                number_of_exist_constrain==number_of_constrain_data & number_of_exist_val==number_of_val_data)];
            
        end % end of if conditation to check (to fill) matrix variable 'XYmap'
        
        %%%%%%%%%%%%%%% END OF ALL FOUR CONDIATIONS .
        
        
    end % end of day loop
    %end % end of i loop
elseif(fields_all==0)
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % 'XYmap' is the matrix 2D map of existed grid pointes (for observation, defatult simulation (REF) , all mod-simulations and interaction simulations (moddata), %
    %constrain simulations and val simulation), represented by index j and i (j is the line number (raw number for upper line to bottom line) and i is the coulmn number from left to right)
    %%%%%%%%%%%%%%%%%%%%%%%%%%
    clear number_of_val_data number_of_constrain_data
    number_of_obs_data=1; % the minimum nuber of observation for each grid point. number of of fields
    number_of_ref_data=number_of_obs_data; % because REF has only one simulation, therefore, the number of fields should be same as 'number_of_obs_data'
    number_of_mod_data=number_of_obs_data*size(datamatrix_new.moddata,3); % the minimum number of Modatat is like the number of obs data multiple by the number of simulation of Moddata.
    if isfield(datamatrix_new, 'valdata')
        number_of_val_data=number_of_obs_data; % the minimum number of Val data is like the number of obs data because there is one simulation of val.
    end
    if isfield(datamatrix_new, 'constrain')
        number_of_constrain_data=number_of_obs_data*size(datamatrix_new.constrain,3); % the minimum number of constrain is like the number of obs data multiple by the number of simulationS of constatin % the number of Val data is like the number of obs data because there is one simulation of val.
    end
    % running on all grid points
    
    % for i=1:size(datatemp.obsdata,4) % runing on all raws in for checking the exsitence of each grid point, the 1D gridd matrix datatemp
    %    i
    for day=1:size(datamatrix_new.obsdata,2) % runing on all fileds in order to check existence of each grid point
        number_of_exist_obs=zeros(NumberOneD,1); % number of exist observation for the grid points which is the number of avaliable fields for the spcific day
        number_of_exist_ref=zeros(NumberOneD,1); % number of exist Reference simulation for the grid points which is the number of avaliable fields for the spcific day
        number_of_exist_moddata=zeros(NumberOneD,1); % number of exist Reference simulation for the grid points which is the number of avaliable fields for the spcific day
        number_of_exist_val=zeros(NumberOneD,1); % number of exist val simulation for the grid points which is the number of avaliable avaliable fields for the spcific day
        number_of_exist_constrain=zeros(NumberOneD,1); % number of exist constrain simulationS for the grid points which is the number of avaliable fields for the spcific day
        number_of_exist_obs=squeeze(sum(~isnan(datatemp.obsdata(1:size(datamatrix_new.obsdata,1),day,1,:))));  % checking if there is an avaliable observation in the specific field and day
        number_of_exist_ref=squeeze(sum(~isnan(datatemp.refdata(1:size(datamatrix_new.refdata,1),day,1,:))));  % checking if there is an avaliable Ref simulation forecast in the specific field and day.
        if isfield(datamatrix_new, 'valdata')
            number_of_exist_val=squeeze(sum(~isnan(datatemp.valdata(1:size(datamatrix_new.valdata,1),day,1,:)))); % checking if there is an avaliable Ref simulation forecast in the specific field and day.
        end
%        for imoddata=1:size(datatemp.moddata,3)
%            length(sum(~isnan(datatemp.moddata(1:size(datamatrix_new.moddata,1),day,imoddata,:))));
%            number_of_exist_moddata=number_of_exist_moddata+squeeze(sum(~isnan(datatemp.moddata(1:size(datamatrix_new.moddata,1),day,imoddata,:)))); % checking if there is an avaliable observation in the specific field and day.
 %       end
        if isfield(datamatrix_new, 'constrain')
            for iconstrain=1:size(datatemp.constrain,3)
                number_of_exist_constrain=number_of_exist_constrain+squeeze(sum(~isnan(datatemp.constrain(1:size(datamatrix_new.constrain,1),day,iconstrain,:)))); % checking if there is an avaliable constrain simuation forecast in the specific field and day.;
            end
        end
        % end % end of fields loop
        % FOUR BLOCKS of "IF COMMAND" FOR 4 combinations with val and constatin if
        % they exist or not , 2 ^2 gives 4 combination.
        %I tried in 'ELSEIF' command and it did not succed therefore i disccueded to try four blocks of "IF COMMAND"
        %%% THE FOUR if condiations is for the 4
        %%% condistions are for the following situations:
        % 1.) val
        %%%simulation and constrain simulations
        %%% do not exist
        if(~isfield(datamatrix_new, 'valdata') && ~isfield(datamatrix_new, 'constrain'))
%            XYmap=[XYmap;find(number_of_exist_moddata>=number_of_mod_data & number_of_exist_ref>=number_of_ref_data & number_of_exist_obs>=number_of_obs_data)];
                        XYmap=[XYmap;find(number_of_exist_ref>=number_of_ref_data & number_of_exist_obs>=number_of_obs_data)];
            
            
        end % end of if conditation to check (to fill) matrix variable 'XYmap'
        % 2.) val simulation exist whereas constrain simulations
        % do not exist
        if(~isfield(datamatrix_new, 'constrain') && isfield(datamatrix_new, 'valdata'))
            
            XYmap=[XYmap;find(number_of_exist_moddata>=number_of_mod_data & number_of_exist_ref>=number_of_ref_data & number_of_exist_obs>=number_of_obs_data & number_of_exist_val>=number_of_val_data)];
            
            
        end % end of calmo_matrix_2D_sizeif conditation to check (to fill) matrix variable 'XYmap'
        % 3.) val simulation does not exist whereas constrain
        % simulations
        % do exist
        if(~isfield(datamatrix_new, 'valdata') && isfield(datamatrix_new, 'constrain'))
            XYmap=[XYmap;find(number_of_exist_moddata>=number_of_mod_data & number_of_exist_ref>=number_of_ref_data & ...
                number_of_exist_obs>=number_of_obs_data & number_of_exist_constrain>=number_of_constrain_data)];
            
        end % end of if conditation to check (to fill) matrix variable 'XYmap'
        % 4.) val simulation and constrain simulations
        % do exist
        if(isfield(datamatrix_new, 'constrain') && isfield(datamatrix_new, 'valdata'))
            
            XYmap=[XYmap;find(number_of_exist_moddata>=number_of_mod_data & number_of_exist_ref>=number_of_ref_data & number_of_exist_obs>=number_of_obs_data & ...
                number_of_exist_constrain>=number_of_constrain_data & number_of_exist_val>=number_of_val_data)];
            
        end % end of if conditation to check (to fill) matrix variable 'XYmap'
        
        %%%%%%%%%%%%%%% END OF ALL FOUR CONDIATIONS .
        
        
    end % end of day loop
    %end % end of i loop
end % end of flag 'fields_all' which checks or at least on field ('0') or all fields ('1')
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
XYmap2=unique(XYmap);  % the number of existed grid with all observations and simulation forecasts that all fileds existed or one at least one field exist at least for one day in the period
igrid=length(XYmap2);
grid_datamatrix=[];

for ij=1:igrid %buliding mat(i,j) in order to remember the i,j order for each grid point.
    yy=XYmap2(ij)-floor(XYmap2(ij)/size(datamatrix_new.obsdata,4))*size(datamatrix_new.obsdata,4);
    xx=ceil(XYmap2(ij)/size(datamatrix_new.obsdata,4));
    grid_datamatrix=[grid_datamatrix;yy,xx];
end
calmo_matrix_2D_size=[size(datamatrix_new.obsdata,4),size(datamatrix_new.obsdata,5)];
%%%% Defined 1D gridded matrix
%nanmean(datatemp.obsdata(3,:))
small_datamatrix.obsdata=NaN(size(datamatrix_new.obsdata,1),size(datamatrix_new.obsdata,2),igrid);
small_datamatrix.refdata=NaN(size(datamatrix_new.refdata,1),size(datamatrix_new.refdata,2),igrid);
small_datamatrix.moddata=NaN(size(datamatrix_new.moddata,1),size(datamatrix_new.moddata,2),igrid,size(datamatrix_new.moddata,3));
display('WRITE STAGE')
size(small_datamatrix.obsdata)
size(small_datamatrix.refdata)
size(small_datamatrix.moddata)
if(isfield(datamatrix_new, 'valdata'))
    small_datamatrix.valdata=NaN(size(datamatrix_new.valdata,1),size(datamatrix_new.valdata,2),igrid);
end
if(isfield(datamatrix_new, 'constrain'))
    small_datamatrix.constrain=NaN(size(datamatrix_new.constrain,1),size(datamatrix_new.constrain,2),igird,size(datamatrix_new.constrain,3));
end
display('THE SECOND STAGE')
%%% Assiging values in the 1D grided matrix
size(XYmap2)
size(datatemp.obsdata)
display('THE THIRD STAGE')
size(small_datamatrix.obsdata)
display('THE FOURTH STAGE')
small_datamatrix.obsdata(1:size(datatemp.obsdata,1),1:size(datatemp.obsdata,2),1:igrid)=datatemp.obsdata(1:size(datatemp.obsdata,1),1:size(datatemp.obsdata,2),XYmap2);
nanmean(small_datamatrix.obsdata(3,:))
size(datatemp.refdata)
small_datamatrix.refdata(1:size(datatemp.refdata,1),1:size(datatemp.refdata,2),1:igrid)=datatemp.refdata(1:size(datatemp.refdata,1),1:size(datatemp.refdata,2),XYmap2);
for gridrun=1:igrid
    for jj=1:size(datatemp.moddata,3)
        small_datamatrix.moddata(1:size(datatemp.moddata,1),1:size(datatemp.moddata,2),gridrun,jj)=datatemp.moddata(1:size(datatemp.moddata,1),1:size(datatemp.moddata,2),jj,XYmap2(gridrun));
    end
end
if(isfield(datamatrix_new, 'valdata'))
    small_datamatrix.valdata(1:size(datatemp.valdata,1),1:size(datatemp.valdata,2),1:igrid)=datatemp.valdata(1:size(datatemp.valdata,1),1:size(datatemp.valdata,2),XYmap2);
end
if(isfield(datamatrix_new, 'constrain'))
    for gridrun=1:igrid
        for jj=1:size(datatemp.constrain,3)
            small_datamatrix.constrain(1:size(datatemp.constrain,1),1:size(datatemp.constrain,2),gridrun,jj)=datatemp.constrain(1:size(datatemp.constrain,1),1:size(datatemp.constrain,2),jj,XYmap2(gridrun));
        end
    end
end
%%%%%%%%%%
%%%% MAP GRID FIGURE STEP (STAGE)
%%%%%%%%%%
%{
mat_new=grid_datamatrix;
figure
    lat3=0:((size(mat_new,2))+1);
    lon3=0:((size(mat_new,1)+1)/(size(mat_new,2)+1)):(size(mat_new,1)+1);
    plot(lon3,lat3,'-')
    yinverse=size(mat_new,2);
    for y=1:size(mat_new,2)
        y
        for x=1:size(mat_new,1)
            if(mat_new(x,yinverse)==0)
                Atext='.' ;
                text(x,y,Atext,'Color','k');
            end
            Atext=' ';
            if(mat_new(x,yinverse)==1)
                Atext='.' ;
                text(x,y,Atext,'Color','r');
            end
            if(isnan(mat_new(x,yinverse)))
                Atext='.';
                 text(x,y,Atext,'Color','y');
            end
           
        end
        yinverse=yinverse-1;
    end
    title('GRID MAT: exist grid red color & black=does not exist'); grid on
    ylabel('index of lat from south to north (down to up)')
    xlabel('indext of lon from right to left (west to east)')
    Aprint='GRID_EXIST_map_of_datamatrix.png';
    print(Aprint,'-dpng')
    close
%}
