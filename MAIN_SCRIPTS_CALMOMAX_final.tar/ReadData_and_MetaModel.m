function ReadData_and_MetaModel_only_Represntive_days(date_min,date_max,Specjulian,Spec_Date2,simtemp)
display('READSTAGE')
% NAME
%   ReadData_and_MetaModel
% PURPOSE
%   Read observations and simulations data, then fit the Meta-Models
% INPUTS
%   time period: from date_min 'dd-mmm-yyyy' to date_max 'dd-mmm-yyyy'
% OUTPUTS
%   saved (in .mat format) observations and simulations fields as well as
%   the Meta-Models coefficients
% AUTHOR
%   Pavel Khain (pavelkh_il@yahoo.com)

% NAME
%   main
% PURPOSE
%   main program of the CALMO parameters tuning method
% NOTE
%   Set main definitions at namelist.m file !
% RUN
%   from Bash: "matlab -nodesktop -nosplash -r main"
%   from Matlab: F5 inside main.m
% INPUT
%   -
% OUTPUT
%   calibration results saved in .mat format
% AUTHORS
%   Pavel Khain (pavelkh_il@yahoo.com)
%   Itsik Carmona (carmonai@ims.gov.il)
%   Originally: Omar Bellprat (omar.belldate_minprat@gmail.com)
Specjulian
Spec_Date2
%clear all;
close all; clc; format long;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% set calibration period and devide it to sub-periods to save MATLAB memory:
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
mm=1;
[maindir simuldir obsdir extdir vars vars_2d avg_fields vars_sound sims_opt ml score w_user lhacc iterations_num best_percent date_min date_max]=namelist();
mmm=1;
%clear all;
%close all; clc; format long;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% set calibration period and devide it to sub-periods to save MATLAB memory:
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

display('TT')
%%% [maindir simuldir obsdir extdir vars vars_2d avg_fields vars_sound sims_opt ml score w_user lhacc iterations_num best_percent date_min date_max]=namelist();
[maindir simuldir obsdir extdir vars vars_2d avg_fields vars_sound sims_opt ml score w_user lhacc iterations_num best_percent date_min date_max]=namelist();
tmp_str=datestr(date_min);
mkdir(tmp_str);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% simtemp (simulation number except default)
simtemp=Simulations_name();
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%------------------------------------------------------------
%-1- namelist:
%------------------------------------------------------------
%clear global comp maindir curdir simuldir;
global comp maindir curdir simuldir obsdir extdir;

[maindir simuldir obsdir extdir vars vars_2d avg_T vars_sound sims_opt ml score w_user lhacc iterations_num best_percent date_min_tot date_max_tot]=namelist();
%------------------------------------------------------------
%-4- Define "parameters" structure
%------------------------------------------------------------

[paramn,paramnt,range,default,expval,valval,simval,sims_reg,sims_inter,sims_con,valcon,param_log,date_min_check,date_max_check]=sims_def(sims_opt);

if datenum(date_min)<datenum(date_min_check) || datenum(date_max)>datenum(date_max_check)
    stop
end
parameters=struct('name',paramn,'range',range','default',default,'experiments', ...
    expval,'constrain',valcon,'validation',valval,'name_tex',paramnt);

run_again=0;
run_again=1;
if run_again==1;
    
    %------------------------------------------------------------
    %-5- Define "datamatrix" structure
    %------------------------------------------------------------
    
    % (1) Read observations
    display('Read obs')
    %    [datamatrix.obsdata datamatrix_s.obsdata datamatrix_s.sound_exist]=read_calmo_obs(vars,date_lim,'clever_mean',length(vars_sound));
    Tdrymax=load([obsdir,'/Tdry_max_Med_Domain.mat']);
    Tdrymin=load([obsdir,'/Tdry_min_Med_Domain.mat']);
    Tdewmax=load([obsdir,'/Tdew_max_Med_Domain.mat']);
    Tdewmin=load([obsdir,'/Tdew_min_Med_Domain.mat']);
    Rain=load([obsdir,'/Rain_Med_Domain.mat']);
    Sday=Specjulian;
    
    for i=1:length(Sday)
        datamatrix.obsdata(1,i,1,:,:)=squeeze(Tdrymax.Tmax(:,:,Sday(i)))+273.15;
        datamatrix.obsdata(2,i,1,:,:)=squeeze(Tdrymin.Tmin(:,:,Sday(i)))+273.15;
        datamatrix.obsdata(3,i,1,:,:)=squeeze(Tdewmax.Tdmax(:,:,Sday(i)))+273.15;
        datamatrix.obsdata(4,i,1,:,:)=squeeze(Tdewmin.Tdmin(:,:,Sday(i)))+273.15;
        datamatrix.obsdata(5,i,1,:,:)=squeeze(Rain.Rain1(:,:,Sday(i)));
    end
    nfile=0;
    % (2) Read reference simulation
    sims={'DEF'};
    %    [datamatrix.refdata datamatrix_s.refdata]=read_calmo_sim(vars,sims,date_lim,datamatrix_s.sound_exist,length(vars_sound));
 %  simtemp{1}='optimum'
   simtemp{1}='default'
 %   simuldir='/ims_projects/Research/models/CALMOMAX/MM_code_Med_Domain_60day_in_2019/simulation/CALMO_pavel/CALMO_pavel/'
    for i=1:length(Sday)
        [simuldir,'/',Spec_Date2{i},'/',simtemp{1},'/tmax_00_00.nc']
        Mfile=[simuldir,'/',Spec_Date2{i},'/',simtemp{1},'/tmax_00_00.nc'];
        if(exist(Mfile)==0)
            nfile=nfile+1;
            Tdrymax=NaN(size(datamatrix.obsdata,4),size(datamatrix.obsdata,5));
            Mfilen{nfile}=Mfile;
        else
            
            Tdrymax=ncread(Mfile,'var15');
        end
        Mfile=[simuldir,'/',Spec_Date2{i},'/',simtemp{1},'/tmin_00_00.nc'];
        if(exist(Mfile)==0)
            nfile=nfile+1;
            Mfilen{nfile}=Mfile;
            Tdrymin=NaN(size(datamatrix.obsdata,4),size(datamatrix.obsdata,5));
        else
            Tdrymin=ncread(Mfile,'var16');
            %elseif(i==5)
            %Tdrymin=ncread(['/ims_data/Research/models/CALMO_Med_Domain/simulation/CALMO_pavel/',Spec_Date2{i},'/default/tmin_00_00.nc'],'var15');
            %size(Tdrymin)
            %end
        end
        Mfile=[simuldir,'/',Spec_Date2{i},'/',simtemp{1},'/tdewmax.nc'];
        if(exist(Mfile)==0)
            nfile=nfile+1;
            Mfilen{nfile}=Mfile;
            Tdewmax=NaN(size(datamatrix.obsdata,4),size(datamatrix.obsdata,5));
        else
            Tdewmax=ncread(Mfile,'var17');
        end
        Mfile=[simuldir,'/',Spec_Date2{i},'/',simtemp{1},'/tdewmin.nc'];
        if(exist(Mfile)==0)
            nfile=nfile+1;
            Mfilen{nfile}=Mfile;
            Tdewmin=NaN(size(datamatrix.obsdata,4),size(datamatrix.obsdata,5));
        else
            Tdewmin=ncread(Mfile,'var17');
        end
        Spec_Date2{i}
        Mfile=[simuldir,'/',Spec_Date2{i},'/',simtemp{1},'/tp_0.nc'];
        if(exist(Mfile)==0)
            
            nfile=nfile+1;
            Mfilen{nfile}=Mfile;
            Rain=NaN(size(datamatrix.obsdata,4),size(datamatrix.obsdata,5));
        else
            Rain=ncread(Mfile,'var61');
        end
        AA=find((Tdewmin(:)-Tdewmax(:))~=0);
        datamatrix.refdata(1,i,1,:,:)=squeeze(Tdrymax(:,:));
        datamatrix.refdata(2,i,1,:,:)=squeeze(Tdrymin(:,:));
        datamatrix.refdata(3,i,1,:,:)=squeeze(Tdewmax(:,:));
        datamatrix.refdata(4,i,1,:,:)=squeeze(Tdewmin(:,:));
        datamatrix.refdata(5,i,1,:,:)=squeeze(Rain(:,:));
    end
    
    display('END OF READING DEFAULT SIMULATIONS')
    
    % (3) Read parameter experiments
    %    [datamatrix.moddata datamatrix_s.moddata]=read_calmo_sim(vars,sims_reg,date_lim,datamatrix_s.sound_exist,length(vars_sound));
    %size: 3-CAPE,SIN,TCWC    29-number of days    st 8- 3h steps in a day  59-number of r.s. station
    
    for j=2:length(simtemp)
        for i=1:length(Sday)
            %TESTTT=['/scratch/ms/il/ili/CALMOMAX/simulation/CALMO_pavel/',Spec_Date2{i},'/default/tmax_00_00.nc']
               Mfile=[simuldir,'/',Spec_Date2{i},'/',simtemp{j},'/tmax_00_00.nc']
           if(exist(Mfile)==0)
                nfile=nfile+1;
                Mfilen{nfile}=Mfile;
                %nmiss{nfile}=Mfile;
                Tdrymax=NaN(size(datamatrix.obsdata,4),size(datamatrix.obsdata,5));
            else
                %if((i==8 & j==1) || (i==2 & j==3) || (i==5 & j==3) || ((i>5 & i<8) & (j==4)) || (j==5 & (i==5 | i==7)) || (j==9 & i==2) || (j==9 & i==4) || (j==10 & i==7) || (j==17 & i==1) ...
                %  || (j==17 & i==4) || (j==17 & i==8) || (j==18 & i==4))
                %Tdrymax=ncread(['/ims_data/Research/models/CALMO_Med_Domain/simulation/CALMO_pavel/',Spec_Date2{i},'/',simtemp{j},'/tmax_00_00.nc'],'var16');
                %elseif((i==8 && j==2) || (i==2 && ((j>=4 & j<=5) || j==11)) || (i==5 && j==4) || (i==8 && j==4) || (j==7 & i==2) || ((j<=11 & j>=9) & i==5) || (j==10 & i==2) || (j==10 & i==8))
                %Tdrymax=ncread(['/ims_data/Research/models/CALMO_Med_Domain/simulation/CALMO_pavel/',Spec_Date2{i},'/',simtemp{j},'/tmax_00_00.nc'],'var17');
                %elseif((i==7 && j==11) || (j==16 && (i==2 || i==4 || i==7)) || (j==17 && i==2) || (j==20 & i==4))
                %Tdrymax=ncread(['/ims_data/Research/models/CALMO_Med_Domain/simulation/CALMO_pavel/',Spec_Date2{i},'/',simtemp{j},'/tmax_00_00.nc'],'var17');
                %elseif(i==5 && j==7)
                %Tdrymax=ncread(['/ims_data/Research/models/CALMO_Med_Domain/simulation/CALMO_pavel/',Spec_Date2{i},'/',simtemp{j},'/tmax_00_00.nc'],'var61');
                %elseif(i==5 && j==12)
                %Tdrymax=ncread(['/ims_data/Research/models/CALMO_Med_Domain/simulation/CALMO_pavel/',Spec_Date2{i},'/',simtemp{j},'/tmax_00_00.nc'],'var15');
                %else
                Tdrymax=ncread(Mfile,'var15');
                %end
           end
                 Mfile=[simuldir,'/',Spec_Date2{i},'/',simtemp{j},'/tmin_00_00.nc'];
            if(exist(Mfile)==0)
                nfile=nfile+1;
                Mfilen{nfile}=Mfile;
                %nmiss{nfile}=Mfile;
                Tdrymin=NaN(size(datamatrix.obsdata,4),size(datamatrix.obsdata,5));
            else
                %if(i~=5 & j<4)
                Tdrymin=ncread(Mfile,'var16');
                %elseif((i==5 & j<3) | (i==6 & j==4))
                %Tdrymin=ncread(['/ims_data/Research/models/CALMO_Med_Domain/simulation/CALMO_pavel/',Spec_Date2{i},'/',simtemp{j},'/tmin_00_00.nc'],'var61');
                %elseif(j==5 & i==2)
                %Tdrymin=ncread(['/ims_data/Research/models/CALMO_Med_Domain/simulation/CALMO_pavel/',Spec_Date2{i},'/',simtemp{j},'/tmin_00_00.nc'],'var17');
                %size(Tdrymin)
                %end
            end
             Mfile=[simuldir,'/',Spec_Date2{i},'/',simtemp{j},'/tdewmax.nc'];
           if(exist(Mfile)==0)
                nfile=nfile+1;
              %  nmiss{nfile}=Mfile;
                Mfilen{nfile}=Mfile;
                Tdewmax=NaN(size(datamatrix.obsdata,4),size(datamatrix.obsdata,5));
            else
                %if((i==7 & j==3) || (i==1 & j==11))
                %Tdewmax=ncread(['/ims_data/Research/models/CALMO_Med_Domain/simulation/CALMO_pavel/',Spec_Date2{i},'/',simtemp{j},'/tdewmax.nc'],'var16');
                %elseif(i==1 & j==7)
                %Tdewmax=ncread(['/ims_data/Research/models/CALMO_Med_Domain/simulation/CALMO_pavel/',Spec_Date2{i},'/',simtemp{j},'/tdewmax.nc'],'var15');
                %else
                Tdewmax=ncread(Mfile,'var17');
                %end
           end
             Mfile=[simuldir,'/',Spec_Date2{i},'/',simtemp{j},'/tdewmin.nc'];
            if(exist(Mfile)==0)
                nfile=nfile+1;
             %   nmiss{nfile}=Mfile;
             Mfilen{nfile}=Mfile;
                Tdewmin=NaN(size(datamatrix.obsdata,4),size(datamatrix.obsdata,5));
            else
                %if((j==7 & i==1) | (j==15 & i==9))
                %Tdewmin=ncread(['/ims_data/Research/models/CALMO_Med_Domain/simulation/CALMO_pavel/',Spec_Date2{i},'/',simtemp{j},'/tdewmin.nc'],'var16');
                %else
                Tdewmin=ncread(Mfile,'var17');
                %end
            end
                   Mfile=[simuldir,'/',Spec_Date2{i},'/',simtemp{j},'/tp_0.nc'];
            if(exist(Mfile)==0)
                nfile=nfile+1;
           %     nmiss{nfile}=Mfile;
           Mfilen{nfile}=Mfile;
                Rain=NaN(size(datamatrix.obsdata,4),size(datamatrix.obsdata,5));
            else
                %if(i==7 & j==2)
                %Rain=ncread(['/ims_data/Research/models/CALMO_Med_Domain/simulation/CALMO_pavel/',Spec_Date2{i},'/',simtemp{j},'/tp_0.nc'],'var16');
                %elseif((i==2 & (j>=9 & j<=10)) || (i==1 & j==20))
                %Rain=ncread(['/ims_data/Research/models/CALMO_Med_Domain/simulation/CALMO_pavel/',Spec_Date2{i},'/',simtemp{j},'/tp_0.nc'],'var15');
                %else
                Rain=ncread(Mfile,'var61');
                %end
            end
            AA=find((Tdewmin(:)-Tdewmax(:))~=0);
            datamatrix.moddata(1,i,j-1,:,:)=squeeze(Tdrymax(:,:));
            datamatrix.moddata(2,i,j-1,:,:)=squeeze(Tdrymin(:,:));
            datamatrix.moddata(3,i,j-1,:,:)=squeeze(Tdewmax(:,:));
            datamatrix.moddata(4,i,j-1,:,:)=squeeze(Tdewmin(:,:));
            datamatrix.moddata(5,i,j-1,:,:)=squeeze(Rain(:,:));
        end
    end
    %}
        
    % (4) Read interaction parameter experiments
    par_num=length(paramn);
    if ~isempty(sims_inter) % IN CASE THERE ARE INTERACTION TERMS:
        %        [datamatrix.moddata(:,:,2*par_num+1:2*par_num+length(sims_inter),:,:) datamatrix_s.moddata(:,:,2*par_num+1:2*par_num+length(sims_inter),:,:)]=read_calmo_sim(vars,sims_inter,date_lim,datamatrix_s.sound_exist,length(vars_sound));
    end
    
    % (5) Read validation experiments
    %if ~strcmp(simval,'MISSING')
    %    %    datamatrix.valdata=read_calmo_sim(vars,simval,date_lim);
    %end
    
    % (6) Read constrain experiments
    sims_con
    if ~strcmp(sims_con,'MISSING') % IN CASE THERE ARE CONSTRAIN (INTERMEDIATE) SIMULATIONS:
        %        [datamatrix.constrain datamatrix_s.constrain]=read_calmo_sim(vars,sims_con,date_lim,datamatrix_s.sound_exist,length(vars_sound));
    end
    
    if ~isempty(strfind([vars{:}],'pr')) || ~isempty(strfind([vars{:}],'t2m_avg')) || ~isempty(strfind([vars{:}],'t2m_max')) || ~isempty(strfind([vars{:}],'t2m_min')) ...
            || ~istempty(strfind([vars{:}],'td2m_avg')) || ~istempty(strfind([vars{:}],'td2m_max')) || ~isempty(strfind([vars{:}],'td2m_min')) || ~isempty(strfind([vars{:}],'sunshine'))
        % if the surf. obs. number for given field,i,j (usually per month) is <3, cancel the entire month
        for f=1:size(datamatrix.obsdata,1)
            f
            for i=1:size(datamatrix.obsdata,4)
                
                for j=1:size(datamatrix.obsdata,5)
                    if sum(~isnan(squeeze(datamatrix.obsdata(f,:,1,i,j))))<3
                        datamatrix.obsdata(f,1:end,1,i,j)=NaN;
                    end
                end
            end
        end
        
        % cancel all the missing Italian grid-points:
        [a]=isnan(datamatrix.obsdata);
        datamatrix.refdata(a==1)=NaN;
        if isfield(datamatrix, 'valdata')
            datamatrix.valdata(a==1)=NaN;
        end
        %        for i=1:size(datamatrix.moddata,3)
        %            clear tmp;
        %            tmp=datamatrix.moddata(:,:,i,:,:);
        %            tmp(a==1)=NaN;
        %            datamatrix.moddata(:,:,i,:,:)=tmp;
        %        end
        if isfield(datamatrix, 'constrain')
            for i=1:size(datamatrix.constrain,3)
                clear tmp;
                tmp=datamatrix.constrain(:,:,i,:,:);
                tmp(a==1)=NaN;
                datamatrix.constrain(:,:,i,:,:)=tmp;
            end
        end
        
        
        % get domain lon/lat:
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        file=[extdir '/lfff00000000c.nc'];
        ncid = netcdf.open(file,'NC_NOWRITE');
        varid_lon = netcdf.inqVarID(ncid,'lon');
        varid_lat = netcdf.inqVarID(ncid,'lat');
        lat  = netcdf.getVar(ncid,varid_lat);
        lon  = netcdf.getVar(ncid,varid_lon);
        lon(lon>180)=lon(lon>180)-360;
        netcdf.close(ncid);
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        
        %--------------------
        display('Redefine datamatrix according C. Frei regions division of Med Domain');
        %--------------------
        if avg_fields==1
            unify_regions=[3 5];    % which regions to unify
            [datamatrix_new] = Frei_regions(datamatrix,lat,lon,vars,unify_regions); %averaging the fields over the regions
        else
            datamatrix_new=datamatrix;
            %convert rain field (if exists) to probability maps (for different thresholds and radiuses)
        end
        
        
        %{
        % this option is problematic because every fieldshas different size
        clear datamatrix
        for i=1:length(vars_2d)
            datamatrix_tmp=gpts_series(datamatrix_new,vars,vars_2d{i});
            datamatrix.obsdata(i,:,:)=datamatrix_tmp.obsdata(1,:,:);
            datamatrix.refdata(i,:,:)=datamatrix_tmp.refdata(1,:,:);
            datamatrix.moddata(i,:,:,:)=datamatrix_tmp.moddata(1,:,:,:);
            if isfield(datamatrix_tmp, 'valdata')
                datamatrix.valdata(i,:,:)=datamatrix_tmp.valdata(1,:,:);
            end
            if isfield(datamatrix_tmp, 'constrain')
                datamatrix.constrain(i,:,:,:)=datamatrix_tmp.constrain(1,:,:,:);
            end
        end
        %}
        clear datamatrix;
        for i=1:length(vars_2d)
            for d=1:size(datamatrix_new.obsdata,2)
                tmp=datamatrix_new.obsdata(i,d,1,:,:); datamatrix.obsdata(i,d,:)=tmp(:);
                tmp=datamatrix_new.refdata(i,d,1,:,:); datamatrix.refdata(i,d,:)=tmp(:);
                        for m=1:size(datamatrix_new.moddata,3)
                            tmp=datamatrix_new.moddata(i,d,m,:,:); datamatrix.moddata(i,d,:,m)=tmp(:);
                        end
                if isfield(datamatrix_new, 'valdata')
                    tmp=datamatrix_new.valdata(i,d,1,:,:); datamatrix.valdata(i,d,:)=tmp(:);
                end
                if isfield(datamatrix_new, 'constrain')
                    for m=1:size(datamatrix_new.constrain,3)
                        tmp=datamatrix_new.constrain(i,d,m,:,:); datamatrix.constrain(i,d,:,m)=tmp(:);
                    end
                end
            end
        end
       datamatrix_new 
        whos datamatrix_new
        % itsik, instead of the following, please write a function which in
        % case of NAN at some g.p (1D) in obs for all the fields and days,
        % set [] for obs and the models.
        datamatrix_backup=datamatrix;
        datamatrix_new_backup=datamatrix_new;
        % fields_all=1; % if 'fields all' equal '1' all fields must be avliable
        fields_all=0; % if 'fields all' equal '0' only one field or above is needed to be avliable no need to all fields to be avaliable
        size(datamatrix_new.obsdata)
        display('STAGE BEFORE  remove_gp_def(datamatrix_new,fields_all) command')
        [small_datamatrix,grid_datamatrix,calmo_matrix_2D_size]=remove_gp_def(datamatrix_new,fields_all);
        whos small_datamatirx
        small_datamatrix
        display('STAGE AFTER  remove_gp(datamatrix_new,fields_all) command')
        display('STAGE OF save grid_datamatrix.mat stage and calmo_matrix_2D_size.mat STAGE')
        save([tmp_str '/grid_datamatrix.mat'],'grid_datamatrix','-v7.3');
        save([tmp_str '/calmo_matrix_2D_size.mat'],'calmo_matrix_2D_size','-v7.3');
    end
   
    
    %{
        small_datamatrix_backup=small_datamatrix;
        clear datamatrix
        small_datamatrix_org=small_datamatrix; % with all fields inclunding  SunShine Duration (or maybe Rel SunShine Duration)
        clear small_datamatrix;
        small_datamatrix.obsdata(1:5,:,:)=small_datamatrix_org.obsdata(1:5,:,:);
        small_datamatrix.obsdata(6,:,:)=small_datamatrix_org.obsdata(7,:,:);
        small_datamatrix.refdata(1:5,:,:)=small_datamatrix_org.refdata(1:5,:,:);
        small_datamatrix.refdata(6,:,:)=small_datamatrix_org.refdata(7,:,:);
        small_datamatrix.moddata(1:5,:,:,:)=small_datamatrix_org.moddata(1:5,:,:,:);
        small_datamatrix.moddata(6,:,:,:)=small_datamatrix_org.moddata(7,:,:,:);
        vars_org=vars;
        clear vars;
        for ij=1:5
            vars{ij}=vars_org{ij};
        end
        vars{6}=vars_org{7};
            vars{7}=vars_org{8};
      vars_2d_org=vars_2d;
            clear vars_2d;
        for ij=1:5
            vars_2d{ij}=vars_2d_org{ij};
        end
        vars_2d{6}=vars_2d_org{7};
    %}
    clear datamatrix
    datamatrix=small_datamatrix;
    size(datamatrix.obsdata)
    
    %save datamatrix.mat datamatrix -v7.3
    display('save datamatrix.mat stage')
    %moddata=datamatrix.moddata;
    %     save([tmp_str '/datamatrix.mat'],'-struct','datamatrix');
    [tmp_str '/datamatrix.mat']
    save([tmp_str '/datamatrix.mat'],'datamatrix','-v7.3')
    %save([tmp_str '/moddata.mat'],'moddata','-v7.3');
 
    %save([tmp_str '/datamatrix.mat'],'datamatrix');
    
    
else
    load('small_datamatrix_backup.mat')
    datamatrix=small_datamatrix_backup;
end
display('return RETRUN BACK THE MACK')




if ~isempty(strfind([vars{:}],'sound'))
    display('STAGE OF grps_series for sound field(s)')
    datamatrix_so=gpts_series(datamatrix_s,vars,'sound');
    
    %%% Assign NaN in Sonde fields that have less than ml observations per month or period. The Assigment is for all days in the specific month and reigons for that specific month and fields.
    datatemp=del_bad_sounding(datamatrix_so,ml,sims_reg,sims_inter,sims_con,simval,vars_sound,date_min,date_max);
    clear datamatrix_so
    datamatrix_so=datatemp;
    display('STAGE OF datamatrix_so.mat stage')
    save([tmp_str '/datamatrix_so.mat'],'-struct','datamatrix_so');
    moddata_s=datamatrix_s.moddata;
    save([tmp_str '/moddata_s.mat'],'moddata_s','-v7.3');
    
    %         save([tmp_str '/datamatrix_so.mat'],'datamatrix_so');
    clear datatemp0
end


%  datamatrix=load([tmp_str '/datamatrix.mat']);
clear datamatrix
load([tmp_str '/datamatrix.mat']);
%datamatrix_so=load([tmp_str '/datamatrix_so.mat']);
display('STAGE OF BEFORE NEELING_E_WITOUT_INTERACTION FOR DATAMATRIX')
W=1
%metamodel=neelin_e_without_interaction(parameters,datamatrix,vars_2d);
%load('/ims_projects/Research/models/CALMOMAX/MM_code_Med_Domain_60day_in_2019/main/log_01_jan_2019_with_default/datamatrix.mat')
%datamatrix
%{
load('01-Jan-2019/datamatrix.mat')
MM=cosi_score_for_only_one_period(datamatrix.refdata,datamatrix.obsdata,W,w_user,1)
[simuldir,'/',Spec_Date2{1},'/',simtemp{1},'/tmax_00_00.nc']
%  save COSI_SCORE_OF_OPTIMUM.txt MM -ascii
save COSI_SCORE_OF_DEFAULT.txt MM -ascii
%}
metamodel=neelin_e(parameters,datamatrix,vars_2d);
display('STAGE OF AFTER NEELING_E_WITOUT_INTERACTION FOR DATAMATRIX and before saving to metamodel.mat')
%save([tmp_str '/metamodel.mat'],'-struct','metamodel');
save([tmp_str '/metamodel.mat'],'metamodel','-v7.3');
%  save([tmp_str '/metamodel.mat'],'metamodel');
if ~isempty(strfind([vars{:}],'sound'))
    %metamodel_so=neelin_e_without_interaction(parameters,datamatrix_so,vars_sound); % structure which contains the fitted metamodel parameters for 18 parmeters including T850,T700mb,T500mb,
    metamodel_so=neelin_e(parameters,datamatrix_so,vars_sound);
    % RH850mb, RH700mb, RH500mb , U850mb, U700mb, U500mb , V850mb, V700mb and V500mb.
    % save([tmp_str '/metamodel_so.mat'],'-struct','metamodel_so');
    save([tmp_str '/metamodel_so.mat'],'metamodel_so','-v7.3');
end
%}
return


