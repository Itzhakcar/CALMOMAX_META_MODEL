function [VectorValues]=expval_inter_combs(temp_inter,range,default,paramn)

% NAME 
%   expval_inter_combs
% PURPOSE 
%   fill expval matrix for sims_def.m
% INPUTS 
%   temp_inter - one of the interaction simulations
%   range - Parameters ranges (min and max)
%   default - Parameters defaults
%   paramn - Parameter names
% OUTPUTS 
%   expval matrix for sims_def.m
% AUTHOR  
%   Itsik Carmona (carmonai@ims.gov.il)
%  paramn={'tkhmin','rlam','tur_len','rat_sea','c_soil'}; % No TEX interpreter
%display('After PARMANBefore sims_inter')
%    paramnt={'tkhmin','rlam','tur_len','rat_sea','c_soil'}; % Parameter names
 %wrong values %  range={[0.4 2];[0.1 10];[5 35];[0.3 0.9];[0 1.0]};    % Parameter ranges (min,default,max)
 %wrong values  %  default={[1.0 1 20 0.5 0.3]};
%      range={[0.1 2];[0.1 2];[100 1000];[1 50];[0 2.0]};    % Parameter ranges (min,default,max)
%    default={[1 1 500 10 1]};


% for sims_inter={'HRATSHTKHM','HCSOIHTURL','HRATSHTURL','HTKHMHTURL','HRLAMLCSOI','HRATSLCSOI','HRATSLRLAM','HRLAMHTKHM','HCSOIHTKHM','HRLAMHTURL'}
          VectorValues=[];
          iend=length(range);
          if(strcmp(temp_inter,'HRATSHTKHM')==1)
            paramn1='rat_sea';
            paramn2='tkhmin';
            max1=2;
            max2=2;
          elseif(strcmp(temp_inter,'HCSOIHTURL'))
            paramn1='c_soil';
            paramn2='tur_len';
            max1=2;
            max2=2;
          elseif(strcmp(temp_inter,'HRATSHTURL'))
            paramn1='rat_sea';
            paramn2='tur_len';
            max1=2;
            max2=2;
          elseif(strcmp(temp_inter,'HTKHMHTURL'))
            paramn1='tkhmin';
            paramn2='tur_len';
            max1=2;
            max2=2;
          elseif(strcmp(temp_inter,'HRLAMLCSOI'))
            paramn1='rlam';
            paramn2='c_soil';
            max1=2;
            max2=1;
          elseif(strcmp(temp_inter,'HRATSLCSOI'))
            paramn1='rat_sea';
            paramn2='c_soil';
            max1=2;
            max2=1;
          elseif(strcmp(temp_inter,'HRATSLRLAM'))
            paramn1='rat_sea';
            paramn2='rlam';
            max1=2;
            max2=1;
          elseif(strcmp(temp_inter,'HRLAMHTKHM'))
            paramn1='rlam';
            paramn2='tkhmin';
%sims_inter={'HRATSHTKHM','HCSOIHTURL','HRATSHTURL','HTKHMHTURL','HRLAMLCSOI','HRATSLCSOI','HRATSLRLAM','HRLAMHTKHM','HCSOIHTKHM','HRLAMHTURL'}
%    paramnt={'tkhmin','rlam','tur_len','rat_sea','c_soil'}; % Parameter names
            max1=2;
            max2=2;
          elseif(strcmp(temp_inter,'HCSOIHTKHM'))
            paramn1='c_soil';
            paramn2='tkhmin';
            max1=2;
            max2=2;
          elseif(strcmp(temp_inter,'HRLAMHTURL'))
            paramn1='rlam';
            paramn2='tur_len';
            max1=2;
            max2=2;
          end
            
                for i=1:iend
            if(strcmp(paramn1,paramn{i}))
          VectorValues=[VectorValues,range{i}(max1)];
            elseif(strcmp(paramn2,paramn{i}))
          VectorValues=[VectorValues,range{i}(max2)];
            else
          VectorValues=[VectorValues,default{1}(i)];
            end
          end
